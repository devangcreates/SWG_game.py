# SWG_game.py
 "A simple Snake Water Gun game built in Python using random module."
